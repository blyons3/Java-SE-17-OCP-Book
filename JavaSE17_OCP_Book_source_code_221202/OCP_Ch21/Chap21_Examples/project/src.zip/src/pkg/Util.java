package project.src.pkg;
// A utility class
public class Util {
  public static void get() {
  }
}